var courseName = "Typescript Bootcamp";
printCourseName(courseName);
function printCourseName(name) {
    console.log("This course name is " + name.toUpperCase());
}
