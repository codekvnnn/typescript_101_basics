
// primitive types: number
const lessonsCount = 10; 

const total = lessonsCount + 10;

console.log("total =", total);


// primitive types: string
let title = "Typescript Bootcamp";

let subtitle = "Learn the language fundamentals, build practical projects";

const fullTitle = title + ": " + subtitle;

console.log("Full title" + fullTitle);

// primitive types: boolean
const published = true;

if(published) {
    console.log("This course is published.");

}