// primitive types: number
var lessonsCount = 10;
var total = lessonsCount + 10;
console.log("total =", total);
// primitive types: string
var title = "Typescript Bootcamp";
var subtitle = "Learn the language fundamentals, build practical projects";
var fullTitle = title + ": " + subtitle;
console.log("Full title" + fullTitle);
// primitive types: boolean
var published = true;
if (published) {
    console.log("This course is published.");
}
