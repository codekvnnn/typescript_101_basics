

const courseName = "Typescript Bootcamp";

printCourseName(courseName);



function printCourseName(name :string) {

    console.log("This course name is " + name.toUpperCase());
    
}